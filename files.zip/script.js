// script.js — logique principale de navigation, login, inscription, jeux

// --------- NAVIGATION (affichage bouton et redirections) ----------

function updateNav() {
  const session = getSession();
  const navAdd = document.getElementById("nav-add");
  const navLogout = document.getElementById("nav-logout");
  const navLogin = document.getElementById("nav-login");
  if (navAdd) navAdd.style.display = (session && session.mode === "owner") ? "inline-block" : "none";
  if (navLogout) navLogout.style.display = (session) ? "inline-block" : "none";
  if (navLogin) navLogin.style.display = (session) ? "none" : "inline-block";
  // Déconnexion
  if (navLogout) navLogout.onclick = (e) => {
    e.preventDefault();
    clearSession();
    window.location.href = "index.html";
  };
}
document.addEventListener("DOMContentLoaded", updateNav);

// --------- ACCUEIL (index.html) : affichage des jeux ----------

if (document.getElementById("game-list")) {
  function renderGames() {
    const games = loadGames();
    const list = document.getElementById("game-list");
    list.innerHTML = "";
    games.forEach(game => {
      const div = document.createElement("div");
      div.className = "game-card";
      div.innerHTML = `
        <div class="game-logo">
          <img src="${game.logo}" alt="${game.title}" style="width:100%;height:100%;object-fit:cover;border-radius:12px;">
        </div>
        <div class="game-title">${game.title}</div>
        <div class="game-desc">${game.desc}</div>
        <div>
          <span class="price">${parseFloat(game.price).toFixed(2)} €</span>
          <span class="old-price">${parseFloat(game.old_price).toFixed(2)} €</span>
        </div>
        <div class="file-label">Fichier : ${game.fileName}</div>
        <a class="download-link" href="downloads/${game.fileName}" download>Télécharger APK/EXE</a>
      `;
      list.appendChild(div);
    });
  }
  document.addEventListener("DOMContentLoaded", renderGames);
}

// --------- LOGIN / INSCRIPTION (login.html) ----------

if (document.getElementById("loginForm")) {
  document.getElementById("loginForm").onsubmit = function(e) {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const pwd = document.getElementById("loginPwd").value;
    if (email === OWNER_EMAIL && pwd === OWNER_PWD) {
      setSession(email, "owner");
      window.location.href = "index.html";
      return;
    }
    let users = getUsers();
    let found = users.find(u => u.email === email && u.pwd === pwd);
    if (found) {
      setSession(email, "user");
      window.location.href = "index.html";
    } else {
      document.getElementById("loginMsg").innerText = "Identifiants incorrects.";
    }
  };
}
if (document.getElementById("signupForm")) {
  document.getElementById("signupForm").onsubmit = function(e) {
    e.preventDefault();
    const email = document.getElementById("signupEmail").value.trim();
    const pwd = document.getElementById("signupPwd").value;
    if (email === OWNER_EMAIL) {
      document.getElementById("signupMsg").innerText = "Cet email est réservé au propriétaire.";
      return;
    }
    let users = getUsers();
    if (users.find(u => u.email === email)) {
      document.getElementById("signupMsg").innerText = "Email déjà inscrit.";
      return;
    }
    saveUser(email, pwd);
    document.getElementById("signupMsg").innerText = "Inscription réussie ! Redirection...";
    setTimeout(() => {
      window.location.href = "index.html";
    }, 1200);
  };
}

// --------- AJOUT DE JEU (add-game.html) ----------

if (document.getElementById("addGameForm")) {
  // Sécurité : seul propriétaire peut accéder
  const session = getSession();
  if (!session || session.mode !== "owner") {
    // Redirection immédiate si non propriétaire
    window.location.href = "login.html";
  } else {
    document.getElementById("addGameForm").onsubmit = function(e) {
      e.preventDefault();
      const logoInput = document.getElementById("gameLogo");
      const title = document.getElementById("gameTitle").value;
      const desc = document.getElementById("gameDesc").value;
      const price = parseFloat(document.getElementById("gamePrice").value);
      const old_price = parseFloat(document.getElementById("gameOldPrice").value);
      const fileInput = document.getElementById("gameFile");
      if (!logoInput.files[0] || !fileInput.files[0]) {
        document.getElementById("addGameMsg").innerText = "Logo et fichier jeu obligatoires.";
        return;
      }
      const file = fileInput.files[0];
      const fileName = file.name;
      const reader = new FileReader();
      reader.onload = function(evt) {
        const logoData = evt.target.result;
        const games = loadGames();
        games.push({
          id: "game-" + Date.now(),
          title, desc, price, old_price,
          logo: logoData,
          fileName
        });
        saveGames(games);
        document.getElementById("addGameMsg").style.color = "#19ffd6";
        document.getElementById("addGameMsg").innerText = "Jeu ajouté ! Redirection...";
        setTimeout(() => {
          window.location.href = "index.html";
        }, 1200);
      };
      reader.readAsDataURL(logoInput.files[0]);
    };
  }
}