# e-com — Boutique de jeux vidéo

## Description

**e-com** est un site e-commerce démo pour vendre et télécharger des jeux vidéo (APK ou EXE), avec gestion de comptes utilisateurs et un mode propriétaire permettant d’ajouter de nouveaux jeux.  
Tout fonctionne en JavaScript pur avec stockage dans le navigateur (localStorage).

---

## Structure des fichiers

```
e-com/
├── index.html               ← Page d’accueil (affiche les jeux)
├── login.html               ← Page de connexion/inscription
├── add-game.html            ← Page d’ajout de jeux (accès propriétaire)
├── about.html               ← Page “À propos”
├── style.css                ← Feuille de style principale
├── script.js                ← Script JS principal (gestion du site)
├── storage.js               ← Gestion localStorage (utilisateurs, jeux)
├── assets/                  ← Dossier contenant les images et logos
│   ├── logo1.png
│   ├── logo2.jpg
│   └── ...
└── downloads/               ← (Optionnel) Fichiers EXE ou APK fictifs à “télécharger”
    ├── jeu1.exe
    ├── jeu2.apk
    └── ...
```

---

## Détail des fichiers et dossiers

- **index.html**  
  Page d’accueil affichant la liste des jeux disponibles, avec leur logo, description, prix, et bouton de téléchargement.

- **login.html**  
  Page dédiée à la connexion et à l’inscription des utilisateurs (avec vérification “propriétaire”).

- **add-game.html**  
  Page réservée au propriétaire pour ajouter de nouveaux jeux (formulaire avec logo, description, fichier APK/EXE, prix…).

- **about.html**  
  Présentation du site, de l’équipe, ou du projet (version “À propos”).

- **style.css**  
  Feuille de style principale, pour l’ensemble du site (design moderne, responsive…).

- **script.js**  
  Script JavaScript principal : gère l’affichage dynamique, la connexion, l’inscription, l’ajout de jeux, etc.

- **storage.js**  
  Module JS qui centralise la gestion des données dans le navigateur (localStorage), pour les utilisateurs et les jeux.

- **assets/**  
  Dossier qui contient toutes les images utilisées (logos des jeux…).

- **downloads/**  
  (Facultatif) Dossier pour stocker des fichiers EXE ou APK fictifs, accessibles en téléchargement depuis les cartes des jeux.

---

## Infos importantes

- **Connexion propriétaire** :  
  Utilise l’email `z@gmail.com` et le mot de passe `aaaa` pour passer en mode propriétaire et gérer les jeux.

- **Technos** :  
  HTML, CSS, JavaScript (aucun backend, tout est en localStorage).

- **Limites** :  
  Les fichiers téléchargés ne sont pas réellement uploadés/stockés côté serveur.

---

## Auteur

Site démo créé par e-com0 (2025).