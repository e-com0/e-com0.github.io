// storage.js — gestion localStorage des utilisateurs et jeux

const USERS_KEY = "ecom_users";
const GAMES_KEY = "ecom_games";
const SESSION_KEY = "ecom_session";
const OWNER_EMAIL = "z@gmail.com";
const OWNER_PWD = "aaaa";

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY)) || [];
}
function saveUser(email, pwd) {
  let users = getUsers();
  users.push({ email, pwd });
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}
function getSession() {
  return JSON.parse(localStorage.getItem(SESSION_KEY));
}
function setSession(email, mode) {
  localStorage.setItem(SESSION_KEY, JSON.stringify({email, mode}));
}
function clearSession() {
  localStorage.removeItem(SESSION_KEY);
}
function loadGames() {
  let games = JSON.parse(localStorage.getItem(GAMES_KEY));
  if (!games) {
    games = [
      {
        id: "magic-rampage",
        title: "Magic Rampage",
        desc: "Un jeu d’action plateforme plein d’aventures et de magie !",
        price: 1.99,
        old_price: 10,
        logo: "assets/logo1.png",
        fileName: "jeu1.apk"
      }
    ];
    localStorage.setItem(GAMES_KEY, JSON.stringify(games));
  }
  return games;
}
function saveGames(games) {
  localStorage.setItem(GAMES_KEY, JSON.stringify(games));
}