const USERS_KEY = "ecom_users";
const GAMES_KEY = "ecom_games";
const OWNER_EMAIL = "z@gmail.com";
const OWNER_PWD = "aaaa";

function loadGames() {
  let games = JSON.parse(localStorage.getItem(GAMES_KEY));
  if (!games) {
    games = [
      {
        id: "magic-rampage",
        title: "Magic Rampage",
        desc: "Un jeu d’action plateforme plein d’aventures et de magie !",
        price: 1.99,
        old_price: 10,
        logo: "https://upload.wikimedia.org/wikipedia/commons/6/65/No-Image-Placeholder.svg",
        fileName: "MagicRampage.apk"
      }
    ];
    localStorage.setItem(GAMES_KEY, JSON.stringify(games));
  }
  return games;
}

function saveGames(games) {
  localStorage.setItem(GAMES_KEY, JSON.stringify(games));
}

function renderGames() {
  const games = loadGames();
  const list = document.getElementById("game-list");
  if (!list) return;
  list.innerHTML = "";
  games.forEach(game => {
    const div = document.createElement("div");
    div.className = "game-card";
    div.innerHTML = `
      <div class="game-logo">
        <img src="${game.logo}" alt="${game.title}" style="width:100%;height:100%;object-fit:cover;border-radius:12px;">
      </div>
      <div class="game-title">${game.title}</div>
      <div class="game-desc">${game.desc}</div>
      <div>
        <span class="price">${parseFloat(game.price).toFixed(2)} €</span>
        <span class="old-price">${parseFloat(game.old_price).toFixed(2)} €</span>
      </div>
      <div class="file-label">Fichier : ${game.fileName}</div>
      <a class="download-link" href="#" onclick="alert('Téléchargement démo: ${game.fileName}')">Télécharger APK/EXE</a>
    `;
    list.appendChild(div);
  });
}

// --- Modal helpers ---
function showModal(id) {
  document.getElementById(id).style.display = "flex";
}
function closeModal(id) {
  document.getElementById(id).style.display = "none";
}

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY)) || [];
}
function saveUser(email, pwd) {
  let users = getUsers();
  users.push({email, pwd});
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function setSession(email, mode) {
  localStorage.setItem("ecom_session", JSON.stringify({email, mode}));
}
function getSession() {
  return JSON.parse(localStorage.getItem("ecom_session"));
}
function clearSession() {
  localStorage.removeItem("ecom_session");
}

document.addEventListener("DOMContentLoaded", () => {
  renderGames();

  // Affichage en fonction du login/propriétaire
  let ownerPanel = document.getElementById("ownerPanel");
  let session = getSession();
  let loginBtn = document.getElementById("loginBtn");
  let signupBtn = document.getElementById("signupBtn");
  let logoutBtn = document.getElementById("logoutBtn");

  function updateNav() {
    session = getSession();
    if (session && session.mode === "owner") {
      ownerPanel.style.display = "inline-block";
      loginBtn.style.display = "none";
      signupBtn.style.display = "none";
      logoutBtn.style.display = "inline-block";
    } else if (session && session.mode === "user") {
      ownerPanel.style.display = "none";
      loginBtn.style.display = "none";
      signupBtn.style.display = "none";
      logoutBtn.style.display = "inline-block";
    } else {
      ownerPanel.style.display = "none";
      loginBtn.style.display = "inline-block";
      signupBtn.style.display = "inline-block";
      logoutBtn.style.display = "none";
    }
  }
  updateNav();

  // Modals
  loginBtn.onclick = e => { e.preventDefault(); showModal("loginModal"); };
  signupBtn.onclick = e => { e.preventDefault(); showModal("signupModal"); };
  logoutBtn.onclick = e => { e.preventDefault(); clearSession(); updateNav(); location.reload(); };
  document.getElementById("closeLogin").onclick = () => closeModal("loginModal");
  document.getElementById("closeSignup").onclick = () => closeModal("signupModal");
  document.getElementById("closeAddGame").onclick = () => closeModal("addGameModal");
  ownerPanel.onclick = e => { e.preventDefault(); showModal("addGameModal"); };

  // Login Form
  document.getElementById("loginForm").onsubmit = function(e) {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const pwd = document.getElementById("loginPwd").value;
    if (email === OWNER_EMAIL && pwd === OWNER_PWD) {
      setSession(email, "owner");
      closeModal("loginModal");
      updateNav();
      location.reload();
      return;
    }
    let users = getUsers();
    let found = users.find(u => u.email === email && u.pwd === pwd);
    if (found) {
      setSession(email, "user");
      closeModal("loginModal");
      updateNav();
      location.reload();
    } else {
      document.getElementById("loginMsg").innerText = "Identifiants incorrects.";
    }
  };

  // Signup Form
  document.getElementById("signupForm").onsubmit = function(e) {
    e.preventDefault();
    const email = document.getElementById("signupEmail").value.trim();
    const pwd = document.getElementById("signupPwd").value;
    if (email === OWNER_EMAIL) {
      document.getElementById("signupMsg").innerText = "Cet email est réservé au propriétaire.";
      return;
    }
    let users = getUsers();
    if (users.find(u => u.email === email)) {
      document.getElementById("signupMsg").innerText = "Email déjà inscrit.";
      return;
    }
    saveUser(email, pwd);
    document.getElementById("signupMsg").innerText = "Inscription réussie ! Connecte-toi.";
  };

  // Add game form (owner)
  document.getElementById("addGameForm").onsubmit = function(e) {
    e.preventDefault();
    let session = getSession();
    if (!session || session.mode !== "owner") {
      alert("Seul le propriétaire peut ajouter des jeux.");
      return;
    }
    const logoInput = document.getElementById("gameLogo");
    const title = document.getElementById("gameTitle").value;
    const desc = document.getElementById("gameDesc").value;
    const price = parseFloat(document.getElementById("gamePrice").value);
    const old_price = parseFloat(document.getElementById("gameOldPrice").value);
    const fileInput = document.getElementById("gameFile");
    if (!logoInput.files[0] || !fileInput.files[0]) {
      alert("Logo et fichier jeu obligatoires.");
      return;
    }
    const file = fileInput.files[0];
    const fileName = file.name;
    const reader = new FileReader();
    reader.onload = function(evt) {
      const logoData = evt.target.result;
      const games = loadGames();
      games.push({
        id: "game-" + Date.now(),
        title, desc, price, old_price,
        logo: logoData,
        fileName
      });
      saveGames(games);
      closeModal("addGameModal");
      renderGames();
    };
    reader.readAsDataURL(logoInput.files[0]);
    document.getElementById("addGameForm").reset();
  };

  // Fermer modals sur clic dehors
  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', function(e){
      if (e.target === modal) modal.style.display = "none";
    });
  });
});